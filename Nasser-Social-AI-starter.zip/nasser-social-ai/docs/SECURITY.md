# Security baseline

- Require authenticated Supabase sessions for all user-owned data.
- Enable RLS on every exposed table and use `auth.uid() = user_id` ownership checks.
- Never use `user_metadata` claims for authorization decisions.
- Never ship service-role, Meta app secret, or OpenAI API keys to the browser.
- Do not store Meta tokens in localStorage, source control, logs, analytics, or client-readable tables.
- Keep OAuth state short-lived and single-use; validate exact redirect URI and issuer; use PKCE where supported.
- Request the minimum Meta scopes needed. Treat user-profile permissions as conditional and subject to Meta review.
- Provide disconnect and data deletion flows; revoke provider tokens where supported.
- Do not scrape Facebook pages or automate personal-profile posting.
- Before production, run Supabase security advisors, dependency audit, RLS tests, and OAuth threat-model review.
