# Product scope — MVP

## In scope
- Arabic RTL dashboard and navigation shell.
- User-owned accounts, imported posts, comments, drafts, and reports.
- Manual CSV/JSON import as the dependable first data path.
- Meta OAuth integration only for approved scopes and assets.
- Content drafting and analytics with human review.
- A future authenticated MCP/API adapter for ChatGPT.

## Out of scope until Meta approval and security review
- Scraping logged-in Facebook pages or personal profiles.
- Collecting Facebook passwords, cookies, or session tokens.
- Automatic posting to a personal Facebook profile.
- Background collection of private messages or non-consenting users' data.
