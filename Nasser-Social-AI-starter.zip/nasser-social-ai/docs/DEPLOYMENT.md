# Deployment and project setup

## Supabase project created

- Project reference: `jokwkhgwqgscflyubfoc`
- Region: `us-east-2`
- Project URL: `https://jokwkhgwqgscflyubfoc.supabase.co`
- Edge Function: `content-assistant`
- Function URL: `https://jokwkhgwqgscflyubfoc.supabase.co/functions/v1/content-assistant`
- JWT verification: enabled
- Database: five application tables created; RLS enabled on all five.

## Frontend

1. Copy `.env.example` to `.env.local`.
2. Install dependencies with `npm install`.
3. Run `npm run dev`.
4. Build with `npm run build`.

The current UI still stores imported posts and drafts in browser `localStorage`; cloud synchronization and the sign-in screen are not implemented yet.

## AI function secrets

In Supabase Dashboard → Edge Functions → Secrets, configure `OPENAI_API_KEY`. Optionally configure `OPENAI_MODEL` and the exact deployed frontend origin in `APP_ALLOWED_ORIGIN`. Never share or commit the API key. The deployed function requires a valid Supabase user JWT. Until the OpenAI secret is configured, it responds with `server_not_configured`.

## Security

The browser publishable key in `.env.example` is intended to be public. Never expose `service_role`, Meta app secrets, or OpenAI keys in frontend variables. Facebook profile access is not guaranteed; use supported Meta permissions or user-exported data.
