# ChatGPT integration status and design

A ChatGPT connector is **not deployed in this starter**. A working integration requires a publicly reachable HTTPS API, authentication strategy, an OpenAPI contract, and an approved connector/app configuration in the target ChatGPT workspace.

Recommended API surface after deployment:

- `GET /api/me` — return the authenticated workspace identity.
- `GET /api/posts` — list only the authenticated user's imported posts.
- `GET /api/drafts` — list the authenticated user's drafts.
- `POST /api/drafts` — create a draft for the authenticated user.
- `POST /api/analyze` — analyze only data owned by the authenticated user.

Requirements:

- Enforce authentication and user ownership server-side on every request.
- Never expose a Supabase service-role key, Meta app secret, or OpenAI key to the browser or ChatGPT tool schema.
- Validate payload sizes and schemas; rate-limit expensive AI operations.
- Keep connector scopes read-only unless a separately reviewed write workflow is genuinely required.
- Provide a privacy policy, data deletion process, and clear user consent.

The current `content-assistant` Edge Function is an authenticated server-side AI helper, not an MCP server or a ChatGPT connector by itself.
