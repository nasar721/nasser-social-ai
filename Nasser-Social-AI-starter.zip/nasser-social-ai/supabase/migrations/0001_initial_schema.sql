-- NASSER SOCIAL AI: initial user-owned data model
create extension if not exists pgcrypto;

create table if not exists public.social_accounts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  provider text not null check (provider in ('meta','manual_import')),
  external_account_id text,
  display_name text not null,
  account_kind text not null default 'personal' check (account_kind in ('personal','page','business','import')),
  connection_status text not null default 'disconnected' check (connection_status in ('disconnected','pending','connected','error')),
  connected_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.content_posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  social_account_id uuid references public.social_accounts(id) on delete set null,
  provider_post_id text,
  body text not null default '',
  permalink text,
  published_at timestamptz,
  imported_at timestamptz not null default now(),
  source text not null default 'manual_import' check (source in ('manual_import','meta_api','draft')),
  metrics jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.content_comments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  post_id uuid not null references public.content_posts(id) on delete cascade,
  provider_comment_id text,
  body text not null,
  created_at_provider timestamptz,
  imported_at timestamptz not null default now()
);

create table if not exists public.content_drafts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null default 'مسودة جديدة',
  body text not null default '',
  status text not null default 'draft' check (status in ('draft','ready','published_manually','archived')),
  planned_for timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.analysis_reports (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  period_start date,
  period_end date,
  summary jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

alter table public.social_accounts enable row level security;
alter table public.content_posts enable row level security;
alter table public.content_comments enable row level security;
alter table public.content_drafts enable row level security;
alter table public.analysis_reports enable row level security;

drop policy if exists "owners manage social accounts" on public.social_accounts;
create policy "owners manage social accounts" on public.social_accounts
  for all to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
drop policy if exists "owners manage posts" on public.content_posts;
create policy "owners manage posts" on public.content_posts
  for all to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
drop policy if exists "owners manage comments" on public.content_comments;
create policy "owners manage comments" on public.content_comments
  for all to authenticated
  using (
    (select auth.uid()) = user_id
    and exists (select 1 from public.content_posts p where p.id = post_id and p.user_id = (select auth.uid()))
  )
  with check (
    (select auth.uid()) = user_id
    and exists (select 1 from public.content_posts p where p.id = post_id and p.user_id = (select auth.uid()))
  );
drop policy if exists "owners manage drafts" on public.content_drafts;
create policy "owners manage drafts" on public.content_drafts
  for all to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
drop policy if exists "owners manage reports" on public.analysis_reports;
create policy "owners manage reports" on public.analysis_reports
  for all to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);

-- Explicit grants are scoped to authenticated users; RLS still enforces row ownership.
grant select, insert, update, delete on public.social_accounts to authenticated;
grant select, insert, update, delete on public.content_posts to authenticated;
grant select, insert, update, delete on public.content_comments to authenticated;
grant select, insert, update, delete on public.content_drafts to authenticated;
grant select, insert, update, delete on public.analysis_reports to authenticated;

-- Query indexes for common owner-scoped views.
create index if not exists social_accounts_user_created_idx on public.social_accounts(user_id, created_at desc);
create index if not exists content_posts_user_published_idx on public.content_posts(user_id, published_at desc);
create index if not exists content_posts_account_idx on public.content_posts(social_account_id);
create index if not exists content_comments_user_created_idx on public.content_comments(user_id, imported_at desc);
create index if not exists content_comments_post_idx on public.content_comments(post_id);
create index if not exists content_drafts_user_updated_idx on public.content_drafts(user_id, updated_at desc);
create index if not exists analysis_reports_user_created_idx on public.analysis_reports(user_id, created_at desc);


-- Maintain updated_at consistently for mutable records.
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists social_accounts_set_updated_at on public.social_accounts;
create trigger social_accounts_set_updated_at before update on public.social_accounts
  for each row execute function public.set_updated_at();
drop trigger if exists content_drafts_set_updated_at on public.content_drafts;
create trigger content_drafts_set_updated_at before update on public.content_drafts
  for each row execute function public.set_updated_at();
